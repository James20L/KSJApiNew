#!/bin/bash

`dirname $0`/bitmode 0 255
sleep 1
`dirname $0`/bitmode 0 0
