package com.catchbest;

/**
 * Created by terry on 17-10-19.
 */

public enum KSJ_WB_MODE {

                KSJ_WB_DISABLE,
            KSJ_SWB_PRESETTINGS,
            KSJ_SWB_AUTO_ONCE,
            KSJ_SWB_AUTO_CONITNUOUS,
            KSJ_SWB_MANUAL,
            KSJ_HWB_PRESETTINGS,
            KSJ_HWB_AUTO_ONCE,
            KSJ_HWB_AUTO_CONITNUOUS,
            KSJ_HWB_MANUAL
}
