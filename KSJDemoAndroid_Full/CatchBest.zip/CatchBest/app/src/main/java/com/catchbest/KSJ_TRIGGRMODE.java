package com.catchbest;

/**
 * Created by terry on 17-10-19.
 */

public enum KSJ_TRIGGRMODE {

    KSJ_TRIGGER_INTERNAL,
    KSJ_TRIGGER_EXTERNAL,
    KSJ_TRIGGER_SOFTWARE,
    KSJ_TRIGGER_FIXFRAMERATE
}
