package com.callback;

import android.Manifest;

/**
 *
 * 类功能描述：6.0运行时权限   </br>
 *   危险  权限 所有用户相关的权限
 * 博客地址：http://blog.csdn.net/androidstarjack
 * @author 老于
 * Created  on 2017/1/3/002
 * @version 1.0 </p> 修改时间：</br> 修改备注：</br>
 */

public class PermissionUsage {
    /**********权限：设备标识，定位********/
//    public static String[] LOCATION_PHONE = {Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.READ_PHONE_STATE, Manifest.permission.INTERNET, Manifest.permission.ACCESS_NETWORK_STATE
//                                            , Manifest.permission.ACCESS_WIFI_STATE, Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.CHANGE_WIFI_STATE
//                                            , Manifest.permission.VIBRATE, Manifest.permission.WAKE_LOCK, Manifest.permission.GET_TASKS};
//
//    /********权限：短信********/
//    public static String[] SMS = {Manifest.permission.RECEIVE_SMS, Manifest.permission.READ_SMS};
//    /**************权限：照相***********************/
//    public static String[] CAMERA = {Manifest.permission.CAMERA};
//    /**********权限：读取文件********/
//    public static String[] READ_EXTRASORE = { Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.CAMERA};
    /**********权限：打电话权限********/
    public static String[] READ_EXTRASORE = { Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE};

//    Manifest.permission.CALL_PHONE,
//    Manifest.permission.WRITE_EXTERNAL_STORAGE,
//    Manifest.permission.READ_EXTERNAL_STORAGE
}
